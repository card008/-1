package geektime.spring.springbucks.dao;

import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class DaoSupportImpl extends SqlSessionDaoSupport implements DaoSupport {

    protected DaoSupportImpl(){}

    @Override
    public <T> List<T> selectList(T entity) {
        String statementPostfix = entity.getClass().getName()+".selectList";
        return selectList(statementPostfix,entity);
    }

    @Override
    public <T> List<T> selectList(T entity, int pageIndex, int pageSize) {
        String statementPostfix = entity.getClass().getName()+".selectList";
        return selectList(statementPostfix,entity,pageIndex,pageSize);
    }

    @Override
    public <T> List<T> selectList(String statementPostfix, T entity, int pageIndex, int pageSize) {
        return getSqlSession().selectList(statementPostfix,entity,new RowBounds(pageIndex,pageSize));
    }

    @Override
    public <T> int insert(T entity) {
        String className = entity.getClass().getName();
        return getSqlSession().insert(className+".insert",entity);
    }

    @Override
    public <T> int update(T entity) {
        String className = entity.getClass().getName();
        return getSqlSession().update(className+".update",entity);
    }

    @Override
    public <T> int delete(T entity) {
        String className = entity.getClass().getName();
        return getSqlSession().delete(className+".delete",entity);
    }

    @Override
    public <T> List<T> selectList(String statementPostfix, T entity) {
        return getSqlSession().selectList(statementPostfix,entity);
    }
}
