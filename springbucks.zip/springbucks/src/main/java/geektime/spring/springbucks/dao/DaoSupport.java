package geektime.spring.springbucks.dao;

import java.util.List;

public interface DaoSupport {
    // 查询  不分页
    public <T> List<T> selectList(T entity);
    // 查询  分页
    public <T> List<T> selectList(T entity,int pageIndex,int pageSize);
    public <T> List<T> selectList(String statementPostfix,T entity,int pageIndex,int pageSize);
    // 插入
    public <T> int insert(T entity);
    // 更新
    public <T> int update(T entity);
    // 删除
    public <T> int delete(T entity);

    public<T> List<T> selectList(String statementPostfix,T entity);
}
