package geektime.spring.springbucks;

import geektime.spring.springbucks.model.Coffee;
import geektime.spring.springbucks.service.CoffeeService;
import io.lettuce.core.ReadFrom;
import lombok.extern.slf4j.Slf4j;
import org.joda.money.Money;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.LettuceClientConfigurationBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.Date;
import java.util.List;

@Slf4j
@EnableTransactionManagement
@SpringBootApplication
@EnableJpaRepositories
@ImportResource("classpath:mappers/datasource.xml")
public class SpringBucksApplication implements ApplicationRunner { ;
	@Autowired
	private CoffeeService coffeeService;

	public static void main(String[] args) {
		SpringApplication.run(SpringBucksApplication.class, args);
	}

	@Bean
	public RedisTemplate<String, Coffee> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
		RedisTemplate<String, Coffee> template = new RedisTemplate<>();
		template.setConnectionFactory(redisConnectionFactory);
		return template;
	}

	@Bean
	public LettuceClientConfigurationBuilderCustomizer customizer() {
		return builder -> builder.readFrom(ReadFrom.MASTER_PREFERRED);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		// 新增coffee
		Coffee coffee = new Coffee();
		coffee.setName("黑咖啡");
		coffee.setPrice(Money.parse("1.23"));
		coffee.setCreateTime(new Date());
		coffee.setUpdateTime(new Date());
		int num = coffeeService.insertCoffee(coffee);
		log.info("新增coffee条数",num);

		// 查询coffee
		Coffee coffee2 = coffeeService.selectCoffee("黑咖啡");
		log.info("查询coffee{}",coffee2.toString());
		// 更新coffee
		coffee.setPrice(Money.parse("2.33"));
		int count = coffeeService.updateCoffee(coffee);
		log.info("更新coffee条数{}",count);

		// 删除coffee
		int size = coffeeService.deleteCoffee(coffee);
		log.info("删除coffee条数{}",size);

		// 分页查询
		List<Coffee> listC = coffeeService.selectLitCoffee(new Coffee(),1,10);
		log.info("分页查询coffee条数{}",listC.size());

	}
}

